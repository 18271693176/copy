Generate Documentation
======================

Requirements
------------

To generate documentation you need to install:

 - Python >= 3.4
 - Sphinx (http://sphinx-doc.org/)


Generate html
-------------
::

    $ make html

The command generates html document inside ``build/html`` dir.
